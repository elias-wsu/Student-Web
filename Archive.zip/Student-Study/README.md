# Student-Study

This application is built using Express JS. Upon downloading this code, CD into the Student-Study folder

Then, run the command 

```
nodemon
```

and open up localhost:3000 in your browser
